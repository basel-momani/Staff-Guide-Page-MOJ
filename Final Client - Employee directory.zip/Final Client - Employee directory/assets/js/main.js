// Language switcher function
function switchLanguage() {
  const langText = document.querySelector(".lang-text");
  langText.textContent = langText.textContent === "ENGLISH" ? "العربية" : "ENGLISH";
}

// for tabs section
function showTab(tabIndex) {
    const tabs = document.querySelectorAll('.tabs-section .tab');
    const tabContents = document.querySelectorAll('.tabs-section .tab-content');

    tabs.forEach(tab => tab.classList.remove('active'));
    tabContents.forEach(content => content.classList.remove('active'));

    tabs[tabIndex].classList.add('active');
    tabContents[tabIndex].classList.add('active');
}


// Sidebar toggle function for hamburger menu
document.addEventListener('DOMContentLoaded', function () {
  const hamburgerMenu = document.querySelector('.hamburger-menu');
  const sidebar = document.getElementById('sidebar');
  const mainContent = document.getElementById('main-content');

  hamburgerMenu.addEventListener('click', function () {
    sidebar.classList.toggle('open');
    mainContent.classList.toggle('shifted');
  });
});



// to maximize the margin-right of page body and padding-right of user nav based on clicking on the button that added the .open class to navbar
document.addEventListener('DOMContentLoaded', function () {
    const sidebar = document.getElementById('sidebar');
    const mainContent = document.querySelector('main');
    const userNav = document.querySelector('.user-nav');
  
    function adjustStyles() {
        if (sidebar.classList.contains('open')) {
            mainContent.style.marginRight = '268px';
            userNav.style.paddingRight = '301px'; 
        } else {
            mainContent.style.marginRight = '90px'; 
            userNav.style.paddingRight = '123px'; 
        }
    }
  
    const observer = new MutationObserver(() => {
        adjustStyles();
    });
  
    observer.observe(sidebar, { attributes: true, attributeFilter: ['class'] });
  
    adjustStyles();
});




















// NEW NEW NEW NEW NEW NEW NEW NEW NEW NEW NEW NEW NEW NEW NEW NEW NEW NEW NEW NEW NEW NEW NEW NEW NEW 



// to show just 3 results by default and show more on click on button (search-results) section  
document.addEventListener("DOMContentLoaded", () => {
    const results = document.querySelectorAll(".result");
    const toggleButton = document.getElementById("toggle-button");
  
    let itemsToShow = 3;
    let currentEndIndex = itemsToShow;
  
    function updateResultsVisibility() {
      results.forEach((result, index) => {
        if (index < currentEndIndex) {
          result.style.display = "flex";
        } else {
          result.style.display = "none";
        }
      });
  
      if (currentEndIndex >= results.length) {
        toggleButton.textContent = "عرض أقل";
      } else {
        toggleButton.textContent = "عرض المزيد";
      }
    }
  
    toggleButton.addEventListener("click", () => {
      if (currentEndIndex >= results.length) {
        currentEndIndex = itemsToShow;
      } else {
        currentEndIndex += itemsToShow;
      }
      updateResultsVisibility();
    });
  
    updateResultsVisibility();
  });
  






















